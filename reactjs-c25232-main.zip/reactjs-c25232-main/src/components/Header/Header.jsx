import { Nav } from "../Nav/Nav";

export const Header = () => {
  return (
    <header>
      <h2>LOGO</h2>
      <Nav />
    </header>
  );
};
