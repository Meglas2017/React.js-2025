export const Footer = () => {
  return (
    <footer>
      <p>Pagina creada por Beluzita</p>
    </footer>
  );
};
